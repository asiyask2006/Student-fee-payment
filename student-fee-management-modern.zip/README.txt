# CampusPay - Student Fee Record Management System

## Requirements
- Node.js installed
- Internet connection for Google Fonts (optional; system fonts are fallback)

## Run on Windows PowerShell
1. Extract this ZIP.
2. Open PowerShell in the folder that contains `package.json`.
3. Run:
   `npm.cmd install`
4. Run:
   `npm.cmd start`
5. Open: http://localhost:3000

## Features
- Sidebar navigation: Dashboard, Students, Record Payment, Receipts, Fee Reports
- Add and edit students, unique roll number validation
- Search students by name, roll number, course or phone
- Record partial or multiple payments
- Automatic paid/partial/pending status and balance calculation
- Unique receipt number for each payment
- Receipt preview and print / Save as PDF
- JSON file storage in `data/students.json`

## Important
The app uses local JSON storage for a college project prototype. Keep backups of `data/students.json`.
