const express = require("express");
const fs = require("fs");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const DB_FILE = path.join(DATA_DIR, "students.json");

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, "[]", "utf8");

function readStudents() {
  try { return JSON.parse(fs.readFileSync(DB_FILE, "utf8") || "[]"); }
  catch { return []; }
}
function writeStudents(students) {
  fs.writeFileSync(DB_FILE, JSON.stringify(students, null, 2), "utf8");
}
function makeId(prefix = "STU") {
  return `${prefix}-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
}
function totals(student) {
  const paid = (student.payments || []).reduce((sum, p) => sum + Number(p.amount || 0), 0);
  const total = Number(student.totalFee || 0);
  return { paid, balance: Math.max(total - paid, 0), status: paid >= total && total > 0 ? "Paid" : paid > 0 ? "Partial" : "Pending" };
}

app.get("/api/students", (req, res) => {
  const q = String(req.query.q || "").toLowerCase().trim();
  let students = readStudents().map(s => ({ ...s, ...totals(s) }));
  if (q) students = students.filter(s =>
    [s.name, s.rollNo, s.course, s.phone].some(v => String(v || "").toLowerCase().includes(q))
  );
  res.json(students);
});

app.post("/api/students", (req, res) => {
  const { name, rollNo, course, phone, totalFee } = req.body;
  if (!name || !rollNo || !course || !Number.isFinite(Number(totalFee)) || Number(totalFee) < 0) {
    return res.status(400).json({ message: "Please enter name, roll number, course and a valid total fee." });
  }
  const students = readStudents();
  if (students.some(s => s.rollNo.toLowerCase() === String(rollNo).toLowerCase())) {
    return res.status(409).json({ message: "This roll number already exists." });
  }
  const student = {
    id: makeId(), name: String(name).trim(), rollNo: String(rollNo).trim(),
    course: String(course).trim(), phone: String(phone || "").trim(),
    totalFee: Number(totalFee), payments: [], createdAt: new Date().toISOString()
  };
  students.unshift(student); writeStudents(students);
  res.status(201).json({ ...student, ...totals(student) });
});

app.put("/api/students/:id", (req, res) => {
  const students = readStudents();
  const index = students.findIndex(s => s.id === req.params.id);
  if (index < 0) return res.status(404).json({ message: "Student not found." });
  const { name, rollNo, course, phone, totalFee } = req.body;
  if (!name || !rollNo || !course || !Number.isFinite(Number(totalFee)) || Number(totalFee) < 0) {
    return res.status(400).json({ message: "Please complete all required fields." });
  }
  if (students.some((s, i) => i !== index && s.rollNo.toLowerCase() === String(rollNo).toLowerCase())) {
    return res.status(409).json({ message: "Another student already uses this roll number." });
  }
  students[index] = { ...students[index], name: String(name).trim(), rollNo: String(rollNo).trim(),
    course: String(course).trim(), phone: String(phone || "").trim(), totalFee: Number(totalFee) };
  writeStudents(students);
  res.json({ ...students[index], ...totals(students[index]) });
});

app.delete("/api/students/:id", (req, res) => {
  const students = readStudents();
  const next = students.filter(s => s.id !== req.params.id);
  if (next.length === students.length) return res.status(404).json({ message: "Student not found." });
  writeStudents(next); res.json({ message: "Student deleted." });
});

app.post("/api/students/:id/payments", (req, res) => {
  const students = readStudents();
  const student = students.find(s => s.id === req.params.id);
  if (!student) return res.status(404).json({ message: "Student not found." });
  const amount = Number(req.body.amount);
  if (!Number.isFinite(amount) || amount <= 0) return res.status(400).json({ message: "Enter a payment amount greater than zero." });
  const current = totals(student);
  if (amount > current.balance) return res.status(400).json({ message: `Amount exceeds remaining balance of ₹${current.balance}.` });
  const payment = {
    id: makeId("REC"), receiptNo: `MBS-${Date.now()}`,
    amount, method: String(req.body.method || "Cash"),
    note: String(req.body.note || "").trim(),
    date: req.body.date ? new Date(req.body.date).toISOString() : new Date().toISOString()
  };
  student.payments = student.payments || [];
  student.payments.unshift(payment);
  writeStudents(students);
  res.status(201).json({ student: { ...student, ...totals(student) }, payment });
});

app.get("/api/receipts", (req, res) => {
  const receipts = [];
  readStudents().forEach(s => (s.payments || []).forEach(p => receipts.push({
    ...p, studentId: s.id, studentName: s.name, rollNo: s.rollNo, course: s.course
  })));
  receipts.sort((a, b) => new Date(b.date) - new Date(a.date));
  res.json(receipts);
});

app.get("/api/summary", (req, res) => {
  const students = readStudents();
  const enriched = students.map(s => ({ ...s, ...totals(s) }));
  res.json({
    students: students.length,
    totalFee: enriched.reduce((a, s) => a + Number(s.totalFee || 0), 0),
    collected: enriched.reduce((a, s) => a + s.paid, 0),
    pending: enriched.reduce((a, s) => a + s.balance, 0),
    recent: enriched.slice(0, 5)
  });
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`Fee Management app running at http://localhost:${PORT}`));
